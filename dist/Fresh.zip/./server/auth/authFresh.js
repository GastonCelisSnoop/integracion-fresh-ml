const authFresh = [
    {
        cuenta: 'snoopfreshdesktest',
        key: 'yPLGYeOxHMbbT81CqUk2:X'
    },
    {
        cuenta: 'snoopcx',
        key: 'dgLkkL6tVD7CWkqxOup:X'
    }
]

exports = authFresh